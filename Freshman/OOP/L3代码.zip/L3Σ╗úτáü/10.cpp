#include <iostream>

using namespace std;

void f(int x, int y)
{
    cout << "int" << endl;
}
void f(int x, double *y)
{
    cout << "pointer" << endl;
}
int main()
{
    f(2, nullptr);
}
