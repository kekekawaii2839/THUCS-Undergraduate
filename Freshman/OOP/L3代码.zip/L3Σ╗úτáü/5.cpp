#include <iostream>
using namespace std;
void print(int score) { cout << "int = " << score << endl; }
void print(float score) { cout << "float = " << score << endl; }
int main() {
    float a = 1.0;
    print(a);  // float = 1
    return 0;
}
