// matrix.h
#ifndef MATRIX_H
#define MATRIX_H

class Matrix {
    int data[6][6];

   public:
    void fill(char dir);
};

#endif
