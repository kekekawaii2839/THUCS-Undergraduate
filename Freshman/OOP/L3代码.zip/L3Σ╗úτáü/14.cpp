class P {
   private:
    int data = 1;
    void add(P a);

   public:
    void add(int i) { data += i; }
};
void P::add(P a) { data += a.data; }  // A

class Q {
   private:
    // void add(P a) { data += a.data; }  // B
   public:
    int data = 2;
};
int main() {
    P a, b;
    Q c;
    int d = c.data;  // C
    // a.add(b);        // D
    a.add(d);        // E
    return 0;
}

