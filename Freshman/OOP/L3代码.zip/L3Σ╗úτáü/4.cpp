#include <iostream>
using namespace std;
void print(int score) { cout << "score = " << score << endl; }
int main() {
    print(1.0);   // score = 1
    print(1.7);   // score = 1
    print(2.3);   // score = 2
    print(-3.9);  // score = -3，向零取整
    return 0;
}
