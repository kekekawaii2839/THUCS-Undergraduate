#include <iostream>

using namespace std;

struct {
    char name[17];
} anon_u;
struct {
    int d;
    decltype(anon_u) id;
} anon_s[100];  // 匿名的struct数组
int main() {
    decltype(anon_s) as;  // 注意变量as的类型:数组
    cin >> as[0].id.name;

    return 0;
}
