class Matrix {
   private:
    int data[6][6];
    void add(Matrix a);

   public:
    void fill(char dir);
};
