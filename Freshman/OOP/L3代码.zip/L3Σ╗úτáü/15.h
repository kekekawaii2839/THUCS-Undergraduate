// test.h
class Test {
    int* data;

   public:
    void setdata(int* d) { data = d; }     //内联函数
    const int* getdata() { return this->data; }  //内联函数
    void operation1(int);
    Test(int i) {
        if (i > 0)
            data = new int[i];
        else
            data = nullptr;
    }                           //内联函数
    ~Test() { delete[] data; }  //内联函数
};
