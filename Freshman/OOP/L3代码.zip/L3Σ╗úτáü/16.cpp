#include <cxxabi.h>

#include <iostream>
#include <typeinfo>

class Test {

};

template <typename T>
char*get_type(const T& instance) {
    return abi::__cxa_demangle(
    typeid((instance)).name(), nullptr, nullptr, nullptr);
}
int main() {
    auto* x = "abc";
    auto y = new int[5];
    auto z = Test();
    std::cout << get_type(x) << std::endl;
    std::cout << get_type(y) << std::endl;
    std::cout << get_type(z) << std::endl;
}
