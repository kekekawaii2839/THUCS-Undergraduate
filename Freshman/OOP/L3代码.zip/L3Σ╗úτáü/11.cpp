#include <iostream>
using namespace std;
int main() {
    int arr[3] = {1, 3, 9};
    for (int e : arr)  // auto e:arr 也可以
        cout << e << endl;
    return 0;
}
