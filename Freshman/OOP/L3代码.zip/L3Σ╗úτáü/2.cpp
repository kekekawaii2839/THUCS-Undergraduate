#include <iostream>

using namespace std;

float f(int s) { return s / 2.0; }
int f(int s) { return s * 2; }

int main()
{
    cout << f(3) << endl;
    //编译器应该调用哪个函数呢? return 0;
}
