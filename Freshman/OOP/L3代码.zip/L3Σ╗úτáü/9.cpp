#include <iostream>

template <typename _Tx, typename _Ty>
void Multiply(_Tx x, _Ty y) {
    auto v = x * y;  //临时变量
    std::cout << v;
}

int main() {
    Multiply(2, 3);    // Multiply(int, int)
    Multiply(2, 3.3);  // Multiply(int, double)
    return 0;
}