#include <iostream>
using namespace std;

int fun(int a = 1) { return a + 1; }
float fun(float a) { return a; }
int fun(int a, int b) { return a + b; }

int main() {
    float a = 1.5;
    int b = 2;
    cout << fun(fun(a, b)) + fun(fun(a), b) << endl;
    return 0;
}
