#include "13.h"

void Matrix::add(Matrix a) {
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++) {
            data[i][j] +=
                a.data[i][j];  // 可以在类内用“.”操作访问同一类下的私有成员
        }
}
