#include <iostream>

using namespace std;

void print(const char* msg) {  // <1>
    cout << "message: " << msg << endl;
}
void print(int score) {  // <2>
    cout << "score = " << score << endl;
}

int main() {
    print("Hello");  //调用print(const char*)
    print(94);       //调用print(int)
    return 0;
}
