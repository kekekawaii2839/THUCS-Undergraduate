#include <iostream>
using namespace std;
void print(float score) { cout << "score = " << score << endl; }
int main()
{
    int a = 1;
    print(a); // 此时会将a转换为float型
    return 0;
}
