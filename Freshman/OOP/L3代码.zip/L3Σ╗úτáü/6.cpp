#include <iostream>
using namespace std;
void print(const char* msg = "hello") { cout << msg << '#'; }
int main() {
    cout << "Beijing...";
    print();
    return 0;
}  // 输出 Beijing...hello#
