// matrix.cpp
#include "12.h"

void Matrix::fill(char dir)  //类外需要类名限定
{
  // 函数实现
}
